
package stringmatematikabooleans;


public class StringMatematikaBooleans {

    
    public static void main(String[] args) {
        
        System.out.println("Beberapa contoh penggunaan code tambahan dan juga penggunaan pada tipe data String dan boolean serta penggunaan Matematika :");
        //Menampilkan panjang string
        String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.println("Panjang dari ABCDEFGHIJKLMNOPQRSTUVWXYZ : " + txt.length());
        
        //Merubah ke huruf besar/kecil
        String nama = "Muhammad Fazron Arif";
        System.out.println("Huruf besar nama saya : " + nama.toUpperCase());
        System.out.println("Huruf kecil nama saya : " + nama.toLowerCase());
        
        //Menemukan karakter dalam string
        String lokasi = "Temukan lokasi dimana 'lokasi' berada :  ";
        System.out.println("Temukan lokasi dimana 'lokasi' berada   :  " + lokasi.indexOf("lokasi"));
        
        //Menampilkan nilai tertinggi/terendah pada angka
        System.out.println("Angka yang paling kecil dari 5 dan 10 = " + Math.min(5,10));
        System.out.println("Angka yang paling besar dari 5 dan 10 = " + Math.max(5,10));
        
        //Menampilkan angka kuadrat dari nilai
        System.out.println("Nilai kuadrat dari  128 adalah " + Math.sqrt(128));
        
        //Mengembalikan positif nilai absolut
        System.out.println("Nilai positif absolut dari -2.7 adalah " + Math.abs(-2.7));
        
        //Mengembalikan nomor acak dari 0(inklusif), dan 1(ekslusif)
        System.out.println("Nilai random dari 0-1 hasilnya yaitu " + Math.random());
        
        //Contoh penggunaan boolean
        boolean javamudah = true;
        boolean javasusah = false;
        int x = 5;
        int y = 10;
        
        System.out.println("Apakah belajar java itu mudah? " + javamudah);
        System.out.println("Apakah belajar java itu sulit? " + javasusah);
        System.out.println("Apakah benar x lebih besar dari y? " + (x > y));
        System.out.println("Apakah benar x = 5? " + (x == 5));
        System.out.println("Apaka benar y = 5? " + (y == 5));
        
        
        
    }
    
}
